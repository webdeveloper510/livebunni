 <title>TMK PRO GAMER | Home </title>
        <!-- page content -->
        <div class="right_col" role="main">
         here
        </div>
        <!-- /page content -->