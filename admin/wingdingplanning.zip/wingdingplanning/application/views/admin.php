
<link href="<?php echo base_url('application/views/backend/css/custom.css');?>" rel="stylesheet">
<style>

body {
    background: url(https://www.intowellness.in/wp-content/themes/INTO_WELLNESS/images/home-banner.jpg);
	background-repeat:no-repeat;
	background-size:cover;
}
.login_wrapper {
    max-width: 466px;
}
.login_form {
    background: rgba(255, 255, 255, 0.75);
    padding: 22px;
}
.login_content h1 {
    color: #fff;
}
#username {
    background-position: 10px 10px !important;
    height: 33px;
    padding: 5px;
    background-color: #fff !important;
}
#password {
    background-position: 10px -53px !important;
    padding: 5px;
	height: 33px;
    background-color: #fff !important;
}
.login_content form input[type="submit"], #content form .submit {
    float: left;
    margin-left: 0px;
    background: #D4202B;
    border: none;
    padding: 10px 20px;
    color: #fff;
    font-size: 15px;
    font-weight: 700;
	cursor:pointer;
}
span#checklogin {
    color: #D4202B;
    text-shadow: none;
    font-size: 17px;
}
.submit-div {
    text-align: center;
}
.submit-div input {
    float: inherit !important;
}
p.privacy-div {
    color: #7e7e7e;
    text-shadow: none;
    font-size: 15px;
}

</style>
<div class="login_wrapper">
	<div class="animate form login_form">
	<section class="login_content">
	 <form action="" method="post">
			<h1>Login Form</h1>
			<div>
			<input type="text" class="form-control" placeholder="Username" id="username" name="username" required="" />
			</div>
			<div>
			<input type="password" class="form-control" placeholder="Password" id="password" name="password" required="" />
			</div>
			<div class="submit-div">
			<input type="submit" class="btn btn-default submit" name="submit" id="loginbackend" value="Log In"/>
			<!--a class="reset_pass" href="#">Lost your password?</a-->
			</div>
		  <span id="checklogin"></span>
		<div class="clearfix"></div>

		<div class="separator">
			<!--p class="change_link">New to site?
			<a href="#signup" class="to_register"> Create Account </a>
			</p-->
			<div class="clearfix"></div>
			<br />
			<div>
			<p class="privacy-div">©2017 All Rights Reserved. Privacy and Terms</p>
			</div>
		</div>
	</form>
	</section>
</div>
