<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Backend extends CI_Controller {
	
		public function __construct() {
			parent::__construct();
			$this->load->library('session');
			//$this->load->driver('Session');
			 $this->load->library('email');
			
				$this->load->model('Backend_model');
				$this->load->database(); 
			     //$this->load->helper('url');
			} 
	
	public function admin()
	{
		$this->load->view('admin');
	}
	public function home(){
		$this->load->view('header');
			$this->load->view('sidebar');
			$this->load->view('top-nav');
			$this->load->view('welcome');
			$this->load->view('footer');
		
		
	}
}
